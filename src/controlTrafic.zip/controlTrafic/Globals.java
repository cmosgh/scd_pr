/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package controlTrafic;

/**
 *
 * @author cmos
 */
public class Globals {
    public static String ipServer = "localhost";
    public static int portServer = 1999;
}
